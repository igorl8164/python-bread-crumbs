from django.urls import path, re_path

from .views import *

urlpatterns = [

    path('', index, name='home'),  # # http://127.0.0.1/wom/  name='home' имя маршрута для ридиректа
    path('index_p/', index_p, name='home_p'),
    # числовой параметр
    path('cats/<int:catid>/', categories),  # # http://127.0.0.1/cats/1/[?...]
    re_path(r'^archive/(?P<year>[0-9]{4})/', archive),
    path('about/', about, name='about'),
    path('addpage/', addpage, name='add_page'),
    path('contact/', contact, name='contact'),
    path('login/', login, name='login'),
    path('post/<int:post_id>/', show_post, name='post'),

    path('about_p/', about_p, name='about_p'),
    path('index_t/', index_t),
    path('about_t/', about_t)
]

# в файле women/views.py функции представлений