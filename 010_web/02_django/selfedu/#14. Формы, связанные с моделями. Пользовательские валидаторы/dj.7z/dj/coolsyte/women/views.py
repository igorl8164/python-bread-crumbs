from django.http import HttpResponse, HttpResponseNotFound, Http404
from django.shortcuts import render, redirect, get_object_or_404

from .forms import *
from .models import *
# Create your views here.

# названия меню и их ссылки
# в файле women/urls.py маршруты к этим страницам
menu = [{'title': "О сайте", 'url_name': 'about'},
        {'title': "Добавить статью", 'url_name': 'add_page'},
        {'title': "Обратная связь", 'url_name': 'contact'},
        {'title': "Войти", 'url_name': 'login'}
]

def index(request):  # класс запроса HttpRequest
    # return HttpResponse("страница приложения women")  # ответ формирует страницу
    posts = Women.objects.all()

    con = {'posts': posts, 'menu': menu, 'title': 'Главная страница', 'cat_selected': 0, }
    return render(request, 'women/index.html', context=con)  # в папке templates women/index.html

def categories(request, catid):
    if request.GET:
        print(request.GET)

    print(catid)
    return HttpResponse(f"<h1> Статьи по категориям </h1> <p>{catid}</p>")

def index_coolsite(request):  # класс запроса HttpRequest
    return HttpResponse("coolsyte")  # ответ формирует страницу

def archive(request, year):
    if int(year) > 2020:
        print(year)
    if int(year) > 2050:
        raise Http404()  # генерация исключения 404 страница не найдена
        # return redirect('home', permanent=False)
    if int(year) < 2000:
        # return redirect('/') # permanent=True 301 постоянное изменение адреса
        return redirect('home', permanent=False)  # 302


    return HttpResponse(f"<h1>Архив по годам</h1><p>{year}</p>")  # возвращает код 200

def pageNotFound(request, exception):
    return HttpResponseNotFound('<h1>Страница не найдена</h1>')  # возвращает код 404


def about(request):
    return render(request, 'women/about.html', {'menu': menu, 'title': 'О сайте'})


def addpage(request):
    # return HttpResponse("Добавление статьи")
    if request.method == 'POST':
        form = AddPostForm(request.POST, request.FILES)
        if form.is_valid():
            print(form.cleaned_data)
            try:
                # Women.objects.create(**form.cleaned_data)
                form.save()
                return redirect('home')
            except:
                form.add_error(None, 'Ошибка добавления поста')
    else:
        form = AddPostForm()
    return render(request, 'women/addpage.html', {'form': form, 'menu': menu, 'title': 'Добавление статьи'})

def contact(request):
    return HttpResponse("Обратная связь")


def login(request):
    return HttpResponse("Авторизация")

def show_post(request, post_slug):
    post = get_object_or_404(Women, slug=post_slug)

    context = {
        'post': post,
        'menu': menu,
        'title': post.title,
        'cat_selected': post.cat_id,
    }

    return render(request, 'women/post.html', context=context)

def about_p(request):
    return render(request, 'women/about_p.html', {'title': 'О сайте', 'menu':menu })

def index_p(request):  # класс запроса HttpRequest
    # return HttpResponse("страница приложения women")  # ответ формирует страницу
    return render(request, 'women/index_p.html', {'title': 'Главная страница', 'menu':menu })  # в папке templates women/index.html  {} словарь передаваемых параметров

def about_t(request):
    r = render(request, 'women/about_t.html', {'title': 'О сайте', 'menu':menu })
    # print(r.getvalue().decode('utf-8'))
    return r

from .models import Women

def index_t(request):
    posts = Women.objects.all()
    return render(request, 'women/index_t.html', {'posts': posts, 'title': 'Главная страница', 'menu':menu })

def show_category(request, cat_id):
    # posts = Women.objects.filter(cat_id=cat_id)
    # if len(posts) == 0:
    #     raise Http404()

    context = {
    #    'posts': posts,
        'menu': menu,
        'title': 'Главная страница',
        'cat_selected': cat_id,
    }

    return render(request, 'women/index.html', context=context)

   # return HttpResponse(f"Отображение категории с id = {cat_id}")
