from django import template
from women.models import *

register = template.Library()

# простой тэг

@register.simple_tag(name='get_cats')
def get_categories(filter=None):
    if not filter:
        cat = Category.objects.all()
    else:
        print(filter)
        cat = Category.objects.filter(pk=filter)
    print('get_categories', cat)
    return cat

# включающий тэг

@register.inclusion_tag('women/list_categories.html')
def show_categories(sort=None, cat_selected=0):
    if not sort:
        cats = Category.objects.all()
    else:
        cats = Category.objects.order_by(sort)

    d = {'var_cats': cats, "cat_selected": cat_selected}
    return d


from django.http import Http404

# @register.simple_tag(name='tag_post')
# def get_post(cat_id=None):
#     if not cat_id:
#         p = Women.objects.all()
#     else:
#         p = Women.objects.filter(cat_id)
#
#     if len(p) == 0:
#         raise Http404()
#
#     return p
