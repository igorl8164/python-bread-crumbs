from django.http import HttpResponse, HttpResponseNotFound, Http404
from django.shortcuts import render, redirect


# Create your views here.

def index(request):  # класс запроса HttpRequest
    return HttpResponse("страница приложения women")  # ответ формирует страницу

def categories(request, catid):
    if request.GET:
        print(request.GET)

    print(catid)
    return HttpResponse(f"<h1> Статьи по категориям </h1> <p>{catid}</p>")

def index_coolsite(request):  # класс запроса HttpRequest
    return HttpResponse("coolsyte")  # ответ формирует страницу

def archive(request, year):
    if int(year) > 2020:
        print(year)
    if int(year) > 2050:
        raise Http404()  # генерация исключения 404 страница не найдена
        # return redirect('home', permanent=False)
    if int(year) < 2000:
        # return redirect('/') # permanent=True 301 постоянное изменение адреса
        return redirect('home', permanent=False)  # 302


    return HttpResponse(f"<h1>Архив по годам</h1><p>{year}</p>")  # возвращает код 200

def pageNotFound(request, exception):
    return HttpResponseNotFound('<h1>Страница не найдена</h1>')  # возвращает код 404
