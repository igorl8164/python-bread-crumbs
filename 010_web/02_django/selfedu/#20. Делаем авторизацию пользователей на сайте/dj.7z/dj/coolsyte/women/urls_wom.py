from django.urls import path, re_path

from .views import *

urlpatterns = [

    # path('', index, name='home'),  # # http://127.0.0.1/wom/  name='home' имя маршрута для ридиректа
    path('', WomenHome.as_view(), name='home'),
    path('index_p/', index_p, name='home_p'),
    # числовой параметр
    path('cats/<int:catid>/', categories),  # # http://127.0.0.1/cats/1/[?...]
    re_path(r'^archive/(?P<year>[0-9]{4})/', archive),
    path('about/', about, name='about'),
    # path('addpage/', addpage, name='add_page'),
    path('addpage/', AddPage.as_view(), name='add_page'),
    path('contact/', contact, name='contact'),
    # path('login/', login, name='login'),
    path('login/', LoginUser.as_view(), name='login'),
    path('logout/', logout_user, name='logout'),
    # path('post/<slug:post_slug>/', show_post, name='post'),
    path('post/<slug:post_slug>/', ShowPost.as_view(), name='post'),
    path('category/<slug:cat_slug>/', WomenCategory.as_view(), name='category'),

    path('about_p/', about_p, name='about_p'),
    path('index_t/', index_t),
    path('about_t/', about_t),

    # path('register/', login, name='register'),
    path('register/', RegisterUser.as_view(), name='register'),
]

# в файле women/views.py функции представлений