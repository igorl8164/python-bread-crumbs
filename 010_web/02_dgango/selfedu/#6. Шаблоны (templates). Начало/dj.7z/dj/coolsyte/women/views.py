from django.http import HttpResponse, HttpResponseNotFound, Http404
from django.shortcuts import render, redirect


# Create your views here.

def index(request):  # класс запроса HttpRequest
    # return HttpResponse("страница приложения women")  # ответ формирует страницу
    return render(request, 'women/index.html')  # в папке templates women/index.html

def categories(request, catid):
    if request.GET:
        print(request.GET)

    print(catid)
    return HttpResponse(f"<h1> Статьи по категориям </h1> <p>{catid}</p>")

def index_coolsite(request):  # класс запроса HttpRequest
    return HttpResponse("coolsyte")  # ответ формирует страницу

def archive(request, year):
    if int(year) > 2020:
        print(year)
    if int(year) > 2050:
        raise Http404()  # генерация исключения 404 страница не найдена
        # return redirect('home', permanent=False)
    if int(year) < 2000:
        # return redirect('/') # permanent=True 301 постоянное изменение адреса
        return redirect('home', permanent=False)  # 302


    return HttpResponse(f"<h1>Архив по годам</h1><p>{year}</p>")  # возвращает код 200

def pageNotFound(request, exception):
    return HttpResponseNotFound('<h1>Страница не найдена</h1>')  # возвращает код 404

def about(request):
    return render(request, 'women/about.html')

menu = ["О сайте", "Добавить статью", "Обратная связь", "Войти"]

def about_p(request):
    return render(request, 'women/about_p.html', {'title': 'О сайте', 'menu':menu })

def index_p(request):  # класс запроса HttpRequest
    # return HttpResponse("страница приложения women")  # ответ формирует страницу
    return render(request, 'women/index_p.html', {'title': 'Главная страница', 'menu':menu })  # в папке templates women/index.html  {} словарь передаваемых параметров

def about_t(request):
    r = render(request, 'women/about_t.html', {'title': 'О сайте', 'menu':menu })
    # print(r.getvalue().decode('utf-8'))
    return r

from .models import Women

def index_t(request):
    posts = Women.objects.all()
    return render(request, 'women/index_t.html', {'posts': posts, 'title': 'Главная страница', 'menu':menu })
